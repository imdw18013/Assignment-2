const mongoose = require('mongoose');


var issuedBookDetailsSchema = new mongoose.Schema({
    bookId:{
        type:String,
        required:true,
    },
    userId:{
        type:String,
        required:true
    },
    issuedDate:{
        type:Date,
        required:true
    },
    submitedDate:{
        type:Date
    }
})

module.exports = mongoose.model(name="IssuedBookDetails",issuedBookDetailsSchema);