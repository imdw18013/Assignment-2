module.exports =   {
    'MongoDbConnection' : 'mongodb+srv://Aditya_21:Adityastudent@bookmanagement.ae0ud.mongodb.net/CRUDDB'
}