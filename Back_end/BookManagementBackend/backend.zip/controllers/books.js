var express = require('express');
var router = express.Router();

const mongoose = require('mongoose')
const BookDetail = require("../models/book")
const BookIssueDetails = require("../models/issueBookDetails");

/* GET BookDetails listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});


// retrive all books details
router.get('/getall', function (req, res, next) {
  var issedBookIds = []
  // getting all issued book ids from db 
  BookIssueDetails.find({},(error, issuedBookDetails) => {
    issedBookIds = issuedBookDetails.map((detail)=>{
    if(detail.submitedDate == null)
        return detail.bookId
    })
    console.log("issued book ids", issedBookIds);

    // getting all books from the database
    BookDetail.find({}, (error, BookDetails) => {
      if (error) {
        res.status(500).send({ "status": false, "message": "failed to get all BookDetail details.", "result": error });
      } else {
        if (BookDetails.length == 0) {
          res.status(200).send({ "status": true, "message": "No BookDetail found", "result": [] })
        } else {

          var data = {
            "bookDetails":BookDetails,
            "issuedBookIds":issedBookIds
          };
          res.status(200).send({ "status": true, "message": "BookDetails found successfully", "result": data});
        }
      }
    })
  })

  
});

// retrive perticualr book details
router.get('/getDetails', function (req, res, next) {
  body = req.query;
  BookDetail.find({ _id: body.bookId }, (error, BookDetails) => {
    if (error) {
      res.status(500).send({ "status": false, "message": "failed to get BookDetail details.", "result": error });
    } else {
      if (BookDetails.length == 0) {
        res.status(200).send({ "status": true, "message": "BookDetail not found with this email id.", "result": "" })
      } else {
        res.status(200).send({ "status": true, "message": "BookDetail found with this email id. ", "result": BookDetails })
      }
    }
  })
});

// add new book detail
router.post('/add', function (req, res, next) {
  console.log(req.body)
  BookDetail.create({
    name: req.body.bookName,
    price: req.body.bookPrice,
    author: req.body.bookAuthor
  }, (error, BookDetailss) => {
    if (error) {
      res.status(500).send({ "status": false, "message": "failed to store BookDetail details.", "result": error });
    } else {
      res.status(200).send({ "status": true, "message": "BookDetail created successfully", "result": BookDetailss })
    }
  });
});

//delete book detail
router.delete('/delete', function (req, res, next) {
  body = req.query;
  BookDetail.deleteOne({ _id: body.bookId }, (error) => {
    if (error) {
      console.log("Error while deleteing BookDetail record ", error)
      res.status(500).send({ "status": false, "message": "failed to delete BookDetail details.", "result": error })
    } else {
      res.status(200).send({ "status": true, "message": "BookDetail deleted successfully", "result": "" })
    }
  })
});

// update book details
router.post('/update', function (req, res, next) {
  console.log(req.body)
  body = req.body;
  BookDetail.findOneAndUpdate({ _id: body.bookId }, { name: body.bookName, price: body.bookPrice, author: body.bookAuthor }, { useFindAndModify: false }, (error, details) => {
    if (error) {
      res.status(500).send({ "status": true, "message": "Updating BookDetail details failed", "result": error })
    } else {
      res.status(200).send({ "status": true, "message": "BookDetail updated successfully", "result": details })
    }
  });
});

// seach book details
router.post('/search', function (req, res, next) {
  console.log(req.body)
  body = req.body;

  var issedBookIds = []
  BookIssueDetails.find({},(error, issuedBookDetails) => {
    issedBookIds = issuedBookDetails.map((detail)=>{
      return detail.bookId
    })
    console.log("issued book ids", issedBookIds);
    BookDetail.find({name:{$regex:body.bookName}}, (error, BookDetails) => {
      if (error) {
        res.status(500).send({ "status": false, "message": "failed to get all BookDetail details.", "result": error });
      } else {
        if (BookDetails.length == 0) {
          res.status(200).send({ "status": true, "message": "No BookDetail found", "result": [] })
        } else {
          var data = {
            "bookDetails":BookDetails,
            "issuedBookIds":issedBookIds
          };
          res.status(200).send({ "status": true, "message": "BookDetails found successfully", "result": data});
        }
      }
    })
  })
});

module.exports = router;
