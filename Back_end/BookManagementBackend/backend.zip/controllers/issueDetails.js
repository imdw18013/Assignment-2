var express = require('express');
var router = express.Router();

const mongoose = require('mongoose')
const BookIssueDetails = require("../models/issueBookDetails");


//book submit
router.post('/submit', function (req, res, next) {
    console.log(req.body)
    body = req.body
    BookIssueDetails.findOneAndUpdate({_id:body.issueId},{submitedDate:getCurrentDate()},(error,details)=>{
        if(error){
          res.status(500).send({ "status": true, "message": "Updating Book issued Details failed", "details": error })
        }else{
          res.status(200).send({ "status": true, "message": "Book issued Details updated successfully", "details": details })
        }
      });
});

//get user issue book details by email id
router.post('/getDetail', function (req, res, next) {
    console.log(req.body)
    body = req.body
    BookIssueDetails.find({ userId: body.emailId, submitedDate:null }, (error, issuedBookDetails) => {
        if (error) {
            res.status(500).send({ "status": false, "message": "failed to get all  user issued details.", "result": error });
        } else {
            if (issuedBookDetails.length == 0) {
                res.status(200).send({ "status": true, "message": "No issue details found", "result": [] })
            } else {
                res.status(200).send({ "status": true, "message": "Book issued Details found successfully", "result": issuedBookDetails })
            }
        }
    })
});


// add new book issue detail
router.post('/add', function (req, res, next) {
    console.log(req.body)
    console.log(getCurrentDate())
    current_date = new Date();
    BookIssueDetails.create({
        bookId: req.body.bookId,
        userId: req.body.userId,
        issuedDate: getCurrentDate(),
        submitedDate:null
    }, (error, BookIssuedDetail) => {
        if (error) {
            res.status(200).send({ "status": false, "message": "failed to store BookIssuedDetail details.", "result": error });
        } else {
            res.status(200).send({ "status": true, "message": "BookIssuedDetail created successfully", "result": BookIssuedDetail })
        }
    });
})



router.post('/history', function (req, res, next) {
    console.log(req.body)
    body = req.body;
    BookIssueDetails.find({userId:body.emailId},null,{"sort":'-issuedDate'}, (error, BookIssuedDetail) => {
        if (error) {
            res.status(200).send({ "status": false, "message": "failed to get issue book history details.", "result": error });
        } else {
            res.status(200).send({ "status": true, "message": "BookIssuedDetail history found", "result": BookIssuedDetail })
        }
    });
})

// this function is used to get current date
function getCurrentDate() {
    let date_ob = new Date();
    // current date
    // adjust 0 before single digit date
    let date = ("0" + date_ob.getDate()).slice(-2);
    // current month
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    // current year
    let year = date_ob.getFullYear();
    return date + "/" + month + "/" + year;
}


module.exports = router;
